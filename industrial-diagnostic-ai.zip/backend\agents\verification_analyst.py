"""
Verification Analyst Agent.

Cross-validates outputs from parallel agents, removes contradictions,
and produces a cleansed, consistent diagnostic statement.
"""

import json
from typing import Any, Dict

from agents.base_agent import BaseAgent


class VerificationAnalystAgent(BaseAgent):

    @property
    def role(self) -> str:
        return "Verification Analyst"

    @property
    def goal(self) -> str:
        return (
            "Cross-validate outputs from the Diagnostic Expert, Pattern Recognition, "
            "and Aggressive Decision agents; remove contradictions; and produce a "
            "consistent, verified diagnostic conclusion."
        )

    def build_prompt(self, question: str, context: str, extra: Dict) -> str:
        diagnostic = extra.get("diagnostic_expert", {})
        pattern = extra.get("pattern_agent", {})
        aggressive = extra.get("aggressive_agent", {})

        diag_text = json.dumps(diagnostic, indent=2) if diagnostic else "Not available"
        pattern_text = json.dumps(pattern, indent=2) if pattern else "Not available"
        aggr_text = json.dumps(aggressive, indent=2) if aggressive else "Not available"

        return f"""
You are a rigorous Verification Analyst for industrial diagnostics.
Your job is to compare outputs from multiple AI agents and produce a verified conclusion.

ORIGINAL QUESTION: {question}

AGENT OUTPUTS TO VERIFY:

--- Diagnostic Expert ---
{diag_text}

--- Pattern Recognition Agent ---
{pattern_text}

--- Aggressive Decision Agent ---
{aggr_text}

INSTRUCTIONS:
1. Identify agreements between agents (areas of consensus).
2. Identify contradictions and explain how you resolve them.
3. Remove unreliable or unsupported claims.
4. Produce a verified, unified diagnostic statement.

Respond ONLY with valid JSON:
{{
  "agreements": ["..."],
  "contradictions_found": ["..."],
  "contradictions_resolved": ["..."],
  "verified_diagnosis": "...",
  "verification_confidence": 0.0
}}
"""

    async def run(self, question: str, context: str, extra: Dict = None) -> Dict[str, Any]:
        result = await super().run(question, context, extra)
        result.setdefault("agreements", [])
        result.setdefault("contradictions_found", [])
        result.setdefault("contradictions_resolved", [])
        result.setdefault("verified_diagnosis", "Verification inconclusive.")
        result.setdefault("verification_confidence", 0.5)
        return result
