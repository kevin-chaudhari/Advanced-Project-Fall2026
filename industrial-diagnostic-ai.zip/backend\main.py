"""
Multi-Agent Industrial Diagnostic AI System — FastAPI Backend
Main application entry point.
"""

import asyncio
import logging
import os
from contextlib import asynccontextmanager
from pathlib import Path

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, UploadFile, File, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

load_dotenv()

from utils.logger import setup_logger
from models.schemas import (
    QueryRequest,
    QueryResponse,
    LoadDataResponse,
    HealthResponse,
)
from data_loader.failure_iq_loader import FailureIQLoader
from data_loader.afrb_loader import AFRBLoader
from rag.faiss_store import FAISSStore
from rag.embedder import Embedder
from agents.orchestrator import AgentOrchestrator

logger = setup_logger(__name__)

# ─── Global state ────────────────────────────────────────────────────────────
embedder: Embedder = None
faiss_store: FAISSStore = None
orchestrator: AgentOrchestrator = None
data_status = {"failure_iq": False, "afrb": False}


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Initialize shared resources on startup."""
    global embedder, faiss_store, orchestrator

    logger.info("🚀 Initialising Industrial Diagnostic AI System …")
    embedder = Embedder()
    faiss_store = FAISSStore(embedder)
    orchestrator = AgentOrchestrator()

    # Auto-load Failure IQ dataset at startup
    try:
        loader = FailureIQLoader()
        docs = loader.load()
        faiss_store.build_index("failure_iq", docs)
        data_status["failure_iq"] = True
        logger.info("✅ Failure IQ index built (%d documents)", len(docs))
    except Exception as exc:
        logger.warning("⚠️  Could not auto-load Failure IQ dataset: %s", exc)

    # Auto-load AFRB if default CSV exists
    afrb_path = os.getenv("AFRB_CSV_PATH", "./data/afrb_sample.csv")
    if Path(afrb_path).exists():
        try:
            loader = AFRBLoader(afrb_path)
            docs = loader.load()
            faiss_store.build_index("afrb", docs)
            data_status["afrb"] = True
            logger.info("✅ AFRB index built (%d documents)", len(docs))
        except Exception as exc:
            logger.warning("⚠️  Could not auto-load AFRB dataset: %s", exc)

    logger.info("✅ System ready.")
    yield
    logger.info("🛑 Shutting down …")


app = FastAPI(
    title="Industrial Diagnostic AI System",
    description="Multi-Agent RAG-based industrial fault diagnosis",
    version="1.0.0",
    lifespan=lifespan,
)

# ─── CORS ────────────────────────────────────────────────────────────────────
origins = os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ─── Routes ──────────────────────────────────────────────────────────────────

@app.get("/health", response_model=HealthResponse, tags=["System"])
async def health():
    """Return system health and data-load status."""
    return HealthResponse(
        status="ok",
        failure_iq_loaded=data_status["failure_iq"],
        afrb_loaded=data_status["afrb"],
        message="Industrial Diagnostic AI System is running",
    )


@app.post("/load-data", response_model=LoadDataResponse, tags=["Data"])
async def load_data(
    dataset_type: str = "failure_iq",
    file: UploadFile | None = File(None),
):
    """
    Load and index a dataset.

    - dataset_type='failure_iq' → auto-loads IBM-style sensor data
    - dataset_type='afrb'       → requires CSV file upload
    """
    global data_status

    dataset_type = dataset_type.lower().strip()

    if dataset_type == "failure_iq":
        try:
            loader = FailureIQLoader()
            docs = loader.load()
            faiss_store.build_index("failure_iq", docs)
            data_status["failure_iq"] = True
            return LoadDataResponse(
                success=True,
                dataset=dataset_type,
                documents_loaded=len(docs),
                message="Failure IQ dataset loaded and indexed successfully.",
            )
        except Exception as exc:
            logger.error("Error loading Failure IQ: %s", exc, exc_info=True)
            raise HTTPException(status_code=500, detail=str(exc))

    elif dataset_type == "afrb":
        if file is None:
            # Try default path
            afrb_path = os.getenv("AFRB_CSV_PATH", "./data/afrb_sample.csv")
            if not Path(afrb_path).exists():
                raise HTTPException(
                    status_code=400,
                    detail="AFRB requires a CSV file upload or a preloaded file at AFRB_CSV_PATH.",
                )
            csv_path = afrb_path
        else:
            # Save uploaded file
            upload_dir = Path("./uploads")
            upload_dir.mkdir(exist_ok=True)
            csv_path = upload_dir / file.filename
            content = await file.read()
            csv_path.write_bytes(content)

        try:
            loader = AFRBLoader(str(csv_path))
            docs = loader.load()
            faiss_store.build_index("afrb", docs)
            data_status["afrb"] = True
            return LoadDataResponse(
                success=True,
                dataset=dataset_type,
                documents_loaded=len(docs),
                message="AFRB dataset loaded and indexed successfully.",
            )
        except Exception as exc:
            logger.error("Error loading AFRB: %s", exc, exc_info=True)
            raise HTTPException(status_code=500, detail=str(exc))

    else:
        raise HTTPException(
            status_code=400,
            detail=f"Unknown dataset_type '{dataset_type}'. Use 'failure_iq' or 'afrb'.",
        )


@app.post("/query", response_model=QueryResponse, tags=["Query"])
async def query(request: QueryRequest):
    """
    Main diagnostic query endpoint.
    Routes to the correct FAISS index and runs the multi-agent pipeline.
    """
    dataset = request.dataset_type.lower().strip()

    if dataset == "failure_iq" and not data_status["failure_iq"]:
        raise HTTPException(
            status_code=400,
            detail="Failure IQ dataset not loaded. POST /load-data?dataset_type=failure_iq first.",
        )
    if dataset == "afrb" and not data_status["afrb"]:
        raise HTTPException(
            status_code=400,
            detail="AFRB dataset not loaded. POST /load-data?dataset_type=afrb first.",
        )

    # RAG retrieval
    index_name = "failure_iq" if dataset == "failure_iq" else "afrb"
    retrieved_docs = faiss_store.search(index_name, request.question, top_k=5)

    # Multi-agent pipeline
    result = await orchestrator.run(
        question=request.question,
        dataset_type=dataset,
        retrieved_docs=retrieved_docs,
    )

    return QueryResponse(**result)


@app.post("/agents/run", tags=["Agents"])
async def agents_run(request: QueryRequest):
    """Internal orchestration endpoint (mirrors /query for direct agent access)."""
    return await query(request)


# ─── Dev entry point ─────────────────────────────────────────────────────────
if __name__ == "__main__":
    import uvicorn

    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True, log_level="info")
