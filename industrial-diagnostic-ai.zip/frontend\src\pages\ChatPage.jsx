import { useState, useRef, useEffect, useCallback } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { Send, RefreshCw, ArrowLeft, Upload, CheckCircle2, AlertTriangle } from 'lucide-react'
import Sidebar from '../components/Sidebar'
import ChatMessage from '../components/ChatMessage'
import LoadingSpinner from '../components/LoadingSpinner'
import { sendQuery, loadDataset, checkHealth } from '../services/api'

const SAMPLE_PROMPTS = {
  failure_iq: [
    'Why is vibration increasing in the pump?',
    'What does a temperature spike of 118°C indicate?',
    'How can I prevent bearing wear in the motor?',
    'Is cavitation causing the pressure drop?',
    'What failure mode is most common in rotating equipment?',
  ],
  afrb: [
    'What is the root cause of the gearbox failure?',
    'Which asset has the highest failure severity?',
    'How does seal failure affect pump performance?',
    'Predict failure from elevated vibration and temperature readings.',
    'What maintenance action should I take for bearing degradation?',
  ],
}

const DATASET_META = {
  failure_iq: { label: 'Failure IQ', color: 'indigo', emoji: '⚡' },
  afrb: { label: 'AFRB', color: 'emerald', emoji: '🔬' },
}

export default function ChatPage() {
  const { dataset } = useParams()
  const navigate = useNavigate()
  const meta = DATASET_META[dataset] || DATASET_META.failure_iq

  const [messages, setMessages] = useState([])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [dataStatus, setDataStatus] = useState({ loaded: false, checking: true })
  const [uploadFile, setUploadFile] = useState(null)
  const [uploadLoading, setUploadLoading] = useState(false)
  const [error, setError] = useState(null)
  const bottomRef = useRef(null)
  const fileInputRef = useRef(null)
  const textareaRef = useRef(null)

  // ── Check backend health ─────────────────────────────────────────────────
  useEffect(() => {
    const check = async () => {
      try {
        const health = await checkHealth()
        const isLoaded =
          dataset === 'failure_iq' ? health.failure_iq_loaded : health.afrb_loaded
        setDataStatus({ loaded: isLoaded, checking: false })
      } catch {
        setDataStatus({ loaded: false, checking: false })
      }
    }
    check()
  }, [dataset])

  // ── Auto-scroll ──────────────────────────────────────────────────────────
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, loading])

  // ── Load dataset ─────────────────────────────────────────────────────────
  const handleLoadDataset = async (file = null) => {
    setUploadLoading(true)
    setError(null)
    try {
      await loadDataset(dataset, file)
      setDataStatus({ loaded: true, checking: false })
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to load dataset.')
    } finally {
      setUploadLoading(false)
    }
  }

  // ── Submit query ─────────────────────────────────────────────────────────
  const handleSubmit = useCallback(async () => {
    const q = input.trim()
    if (!q || loading) return

    setInput('')
    setError(null)
    setMessages((prev) => [...prev, { role: 'user', content: q }])
    setLoading(true)

    try {
      const result = await sendQuery(q, dataset)
      setMessages((prev) => [...prev, { role: 'assistant', content: result }])
    } catch (err) {
      const detail = err.response?.data?.detail || err.message || 'Query failed.'
      setError(detail)
      setMessages((prev) => [
        ...prev,
        { role: 'error', content: detail },
      ])
    } finally {
      setLoading(false)
    }
  }, [input, loading, dataset])

  // ── Keyboard submit ──────────────────────────────────────────────────────
  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSubmit()
    }
  }

  // ── Sample prompt click ──────────────────────────────────────────────────
  const insertSample = (text) => {
    setInput(text)
    textareaRef.current?.focus()
  }

  return (
    <div className="min-h-screen flex bg-[var(--bg-primary)] overflow-hidden">
      {/* ── Sidebar ──────────────────────────────────────────────────────── */}
      <Sidebar
        dataset={dataset}
        meta={meta}
        dataStatus={dataStatus}
        onLoadDataset={() => handleLoadDataset()}
        onSwitchDataset={() => navigate('/')}
        fileInputRef={fileInputRef}
        onFileUpload={(f) => { setUploadFile(f); handleLoadDataset(f) }}
        uploadLoading={uploadLoading}
      />

      {/* ── Main Chat Area ────────────────────────────────────────────────── */}
      <div className="flex flex-col flex-1 min-w-0">
        {/* Header */}
        <div className="flex items-center gap-4 px-6 py-4 border-b border-white/5 bg-[var(--bg-secondary)]/50 backdrop-blur-sm">
          <button
            onClick={() => navigate('/')}
            className="p-2 rounded-lg hover:bg-white/10 text-[var(--text-muted)] hover:text-white transition-colors"
            title="Back to Home"
          >
            <ArrowLeft size={18} />
          </button>
          <div>
            <h1 className="text-lg font-bold text-white">
              {meta.emoji} Industrial Diagnostic AI
            </h1>
            <p className="text-xs text-[var(--text-muted)]">
              Dataset: <span className="text-primary-400 font-medium">{meta.label}</span>
              {dataStatus.loaded && (
                <span className="ml-2 text-accent-400">● Live</span>
              )}
            </p>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto px-6 py-6 space-y-6">
          {/* Welcome message */}
          {messages.length === 0 && !loading && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-16"
            >
              <div className="text-6xl mb-4">{meta.emoji}</div>
              <h2 className="text-2xl font-bold text-white mb-2">
                Ask a Diagnostic Question
              </h2>
              <p className="text-[var(--text-muted)] mb-8 max-w-md mx-auto">
                Six AI agents will collaborate to analyse your query using the{' '}
                <strong className="text-primary-400">{meta.label}</strong> dataset.
              </p>
              {/* Sample prompts */}
              <div className="flex flex-wrap gap-2 justify-center max-w-xl mx-auto">
                {SAMPLE_PROMPTS[dataset]?.map((p) => (
                  <button
                    key={p}
                    onClick={() => insertSample(p)}
                    className="text-sm px-4 py-2 rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 text-[var(--text-muted)] hover:text-white transition-all"
                  >
                    {p}
                  </button>
                ))}
              </div>
            </motion.div>
          )}

          <AnimatePresence initial={false}>
            {messages.map((msg, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <ChatMessage message={msg} />
              </motion.div>
            ))}
          </AnimatePresence>

          {loading && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex justify-start"
            >
              <LoadingSpinner />
            </motion.div>
          )}

          <div ref={bottomRef} />
        </div>

        {/* Error banner */}
        <AnimatePresence>
          {error && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="mx-6 mb-2 flex items-center gap-2 px-4 py-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-sm"
            >
              <AlertTriangle size={16} />
              <span className="flex-1">{error}</span>
              <button onClick={() => setError(null)} className="hover:text-white transition-colors">✕</button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Input Area */}
        <div className="px-6 pb-6 pt-2">
          {!dataStatus.loaded && !dataStatus.checking && (
            <div className="mb-3 flex items-center gap-2 px-4 py-2 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 text-sm">
              <AlertTriangle size={15} />
              Dataset not loaded — queries may fail. Use the sidebar to load it.
            </div>
          )}
          <div className="flex items-end gap-3 glass-card p-3">
            <textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask a diagnostic question… (Shift+Enter for new line)"
              rows={2}
              className="flex-1 bg-transparent text-white placeholder-[var(--text-muted)] text-sm resize-none outline-none min-h-[44px] max-h-[120px] py-1"
            />
            <button
              id="send-query-btn"
              onClick={handleSubmit}
              disabled={!input.trim() || loading}
              className="btn-glow p-3 rounded-xl text-white disabled:opacity-40 disabled:cursor-not-allowed disabled:transform-none flex-shrink-0"
              title="Send Query (Enter)"
            >
              <Send size={18} />
            </button>
          </div>
          <p className="text-center text-[10px] text-[var(--text-muted)] mt-2">
            Enter to send • Shift+Enter for new line • Powered by 6-Agent AI Pipeline
          </p>
        </div>
      </div>
    </div>
  )
}
