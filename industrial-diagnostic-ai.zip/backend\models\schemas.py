"""Pydantic schemas for request/response models."""

from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


class QueryRequest(BaseModel):
    question: str = Field(..., min_length=3, description="Natural language diagnostic question")
    dataset_type: str = Field(..., description="'failure_iq' or 'afrb'")
    top_k: int = Field(default=5, ge=1, le=20, description="Number of RAG documents to retrieve")


class AgentContributions(BaseModel):
    diagnostic_expert: str
    pattern_agent: str
    aggressive_agent: str
    verification: str
    ambiguity: str
    final_decision: str


class QueryResponse(BaseModel):
    final_diagnosis: str
    confidence: float = Field(..., ge=0.0, le=1.0)
    reasoning: List[str]
    supporting_evidence: List[str]
    agent_contributions: AgentContributions
    ambiguity: bool
    dataset_used: str
    retrieved_context_count: int


class LoadDataResponse(BaseModel):
    success: bool
    dataset: str
    documents_loaded: int
    message: str


class HealthResponse(BaseModel):
    status: str
    failure_iq_loaded: bool
    afrb_loaded: bool
    message: str


class RetrievedDocument(BaseModel):
    content: str
    score: float
    metadata: Dict[str, Any] = {}
