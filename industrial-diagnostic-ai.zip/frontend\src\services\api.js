import axios from 'axios'

const BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000'

const api = axios.create({
  baseURL: BASE_URL,
  timeout: 120000, // 2 min for LLM calls
  headers: { 'Content-Type': 'application/json' },
})

/**
 * Check backend health and data-load status.
 * @returns {{ status, failure_iq_loaded, afrb_loaded, message }}
 */
export const checkHealth = async () => {
  const { data } = await api.get('/health')
  return data
}

/**
 * Load a dataset by type.
 * @param {'failure_iq'|'afrb'} datasetType
 * @param {File|null} file - CSV file for AFRB upload
 */
export const loadDataset = async (datasetType, file = null) => {
  if (file) {
    const form = new FormData()
    form.append('file', file)
    const { data } = await api.post(
      `/load-data?dataset_type=${datasetType}`,
      form,
      { headers: { 'Content-Type': 'multipart/form-data' } }
    )
    return data
  }
  const { data } = await api.post(`/load-data?dataset_type=${datasetType}`)
  return data
}

/**
 * Send a diagnostic query.
 * @param {string} question
 * @param {'failure_iq'|'afrb'} datasetType
 * @param {number} topK
 */
export const sendQuery = async (question, datasetType, topK = 5) => {
  const { data } = await api.post('/query', {
    question,
    dataset_type: datasetType,
    top_k: topK,
  })
  return data
}

export default api
