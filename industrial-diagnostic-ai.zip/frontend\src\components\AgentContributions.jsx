import { useState } from 'react'
import { ChevronDown, Users } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'

const AGENT_META = {
  diagnostic_expert:  { label: 'Diagnostic Expert', emoji: '🧠', color: 'border-purple-500/40 bg-purple-500/5' },
  pattern_agent:      { label: 'Pattern Recognition', emoji: '🔍', color: 'border-blue-500/40 bg-blue-500/5' },
  aggressive_agent:   { label: 'Aggressive Decision', emoji: '⚡', color: 'border-amber-500/40 bg-amber-500/5' },
  verification:       { label: 'Verification Analyst', emoji: '✅', color: 'border-emerald-500/40 bg-emerald-500/5' },
  ambiguity:          { label: 'Ambiguity Detection', emoji: '🎯', color: 'border-red-500/40 bg-red-500/5' },
  final_decision:     { label: 'Final Decision', emoji: '🏁', color: 'border-indigo-500/40 bg-indigo-500/5' },
}

export default function AgentContributions({ contributions }) {
  const [open, setOpen] = useState(false)

  const entries = Object.entries(contributions).filter(([, v]) => v)

  return (
    <div className="glass-card overflow-hidden">
      <button
        id="agents-accordion-toggle"
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between p-5 hover:bg-white/5 transition-colors"
        aria-expanded={open}
      >
        <div className="flex items-center gap-2">
          <Users size={16} className="text-primary-400" />
          <span className="text-sm font-semibold text-white">Agent Contributions</span>
          <span className="text-xs text-[var(--text-muted)]">({entries.length} agents)</span>
        </div>
        <motion.div animate={{ rotate: open ? 180 : 0 }} transition={{ duration: 0.2 }}>
          <ChevronDown size={18} className="text-[var(--text-muted)]" />
        </motion.div>
      </button>

      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            key="agents"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <div className="px-5 pb-5 grid grid-cols-1 sm:grid-cols-2 gap-3 border-t border-white/5 pt-4">
              {entries.map(([key, value]) => {
                const meta = AGENT_META[key] || { label: key, emoji: '🤖', color: 'border-white/10 bg-white/5' }
                return (
                  <div
                    key={key}
                    id={`agent-${key}`}
                    className={`rounded-xl border p-4 ${meta.color}`}
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-base">{meta.emoji}</span>
                      <span className="text-xs font-semibold text-white">{meta.label}</span>
                    </div>
                    <p className="text-xs text-[var(--text-muted)] leading-relaxed">{value}</p>
                  </div>
                )
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
