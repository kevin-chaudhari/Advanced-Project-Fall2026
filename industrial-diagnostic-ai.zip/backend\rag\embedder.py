"""
Sentence-Transformer embedding model wrapper.
Caches the model at module level to avoid repeated loads.
"""

import os
from typing import List

import numpy as np
from sentence_transformers import SentenceTransformer

from utils.logger import setup_logger

logger = setup_logger(__name__)

_MODEL_INSTANCE: SentenceTransformer | None = None


class Embedder:
    """Wrapper around a SentenceTransformer model for generating embeddings."""

    def __init__(self):
        global _MODEL_INSTANCE
        model_name = os.getenv("EMBEDDING_MODEL", "all-MiniLM-L6-v2")
        if _MODEL_INSTANCE is None:
            logger.info("Loading embedding model: %s", model_name)
            _MODEL_INSTANCE = SentenceTransformer(model_name)
            logger.info("Embedding model loaded.")
        self.model = _MODEL_INSTANCE
        self.dimension = self.model.get_sentence_embedding_dimension()

    def embed(self, texts: List[str]) -> np.ndarray:
        """
        Embed a list of strings.
        Returns float32 numpy array of shape (len(texts), dimension).
        """
        if not texts:
            return np.empty((0, self.dimension), dtype=np.float32)
        embeddings = self.model.encode(texts, show_progress_bar=False, convert_to_numpy=True)
        return embeddings.astype(np.float32)

    def embed_single(self, text: str) -> np.ndarray:
        """Embed a single string. Returns shape (1, dimension)."""
        return self.embed([text])
