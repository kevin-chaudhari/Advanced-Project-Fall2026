"""
Agent Orchestrator.

Executes the multi-agent pipeline in the prescribed order:
  Phase 1 (Parallel): Pattern Recognition | Aggressive Decision | Diagnostic Expert
  Phase 2 (Serial):   Verification Analyst
  Phase 3 (Serial):   Ambiguity Detection
  Phase 4 (Serial):   Human Review Coordinator → Final Output
"""

import asyncio
from typing import Any, Dict, List

from agents.diagnostic_expert import DiagnosticExpertAgent
from agents.aggressive_decision import AggressiveDecisionAgent
from agents.pattern_recognition import PatternRecognitionAgent
from agents.verification_analyst import VerificationAnalystAgent
from agents.ambiguity_detection import AmbiguityDetectionAgent
from agents.human_review_coordinator import HumanReviewCoordinatorAgent
from agents.base_agent import BaseAgent
from utils.logger import setup_logger

logger = setup_logger(__name__)


class AgentOrchestrator:
    """Coordinates the full multi-agent pipeline."""

    def __init__(self):
        self.diagnostic_expert = DiagnosticExpertAgent()
        self.aggressive_decision = AggressiveDecisionAgent()
        self.pattern_recognition = PatternRecognitionAgent()
        self.verification_analyst = VerificationAnalystAgent()
        self.ambiguity_detection = AmbiguityDetectionAgent()
        self.human_review_coordinator = HumanReviewCoordinatorAgent()

    async def run(
        self,
        question: str,
        dataset_type: str,
        retrieved_docs: List[Dict],
    ) -> Dict[str, Any]:
        """
        Execute the full pipeline and return the final structured response.

        Args:
            question: User's natural language diagnostic question
            dataset_type: 'failure_iq' or 'afrb'
            retrieved_docs: Top-k documents from FAISS retrieval
        """
        logger.info("=== Agent Pipeline START | dataset=%s ===", dataset_type)

        # Format context for prompts
        context = BaseAgent.format_context(retrieved_docs)
        retrieval_scores = [doc.get("score", 0.0) for doc in retrieved_docs]

        # ── Phase 1: Parallel execution ───────────────────────────────────────
        logger.info("Phase 1: Launching parallel agents …")
        diag_result, aggr_result, pattern_result = await asyncio.gather(
            self.diagnostic_expert.run(question, context),
            self.aggressive_decision.run(question, context),
            self.pattern_recognition.run(
                question, context, extra={"retrieval_scores": retrieval_scores}
            ),
        )
        logger.info("Phase 1 complete.")

        # ── Phase 2: Verification ─────────────────────────────────────────────
        logger.info("Phase 2: Verification Analyst …")
        ver_result = await self.verification_analyst.run(
            question,
            context,
            extra={
                "diagnostic_expert": diag_result,
                "pattern_agent": pattern_result,
                "aggressive_agent": aggr_result,
            },
        )
        logger.info("Phase 2 complete.")

        # ── Phase 3: Ambiguity Detection ──────────────────────────────────────
        logger.info("Phase 3: Ambiguity Detection …")
        amb_result = await self.ambiguity_detection.run(
            question,
            context,
            extra={"verification": ver_result},
        )
        logger.info("Phase 3 complete.")

        # ── Phase 4: Final Synthesis ──────────────────────────────────────────
        logger.info("Phase 4: Human Review Coordinator …")
        final_result = await self.human_review_coordinator.run(
            question,
            context,
            extra={
                "diagnostic_expert": diag_result,
                "pattern_agent": pattern_result,
                "aggressive_agent": aggr_result,
                "verification": ver_result,
                "ambiguity": amb_result,
            },
        )
        logger.info("Phase 4 complete.")

        # ── Assemble final response ───────────────────────────────────────────
        final_result["dataset_used"] = dataset_type
        final_result["retrieved_context_count"] = len(retrieved_docs)

        # Ensure agent_contributions is an AgentContributions-compatible dict
        ac = final_result.get("agent_contributions", {})
        ac.setdefault(
            "diagnostic_expert",
            diag_result.get("analysis", diag_result.get("primary_hypothesis", "N/A")),
        )
        ac.setdefault(
            "pattern_agent",
            pattern_result.get("dominant_failure_signature", "N/A"),
        )
        ac.setdefault(
            "aggressive_agent",
            aggr_result.get("decision", "N/A"),
        )
        ac.setdefault(
            "verification",
            ver_result.get("verified_diagnosis", "N/A"),
        )
        ac.setdefault(
            "ambiguity",
            amb_result.get("ambiguity_summary", "N/A"),
        )
        ac.setdefault("final_decision", final_result.get("final_diagnosis", "N/A"))
        final_result["agent_contributions"] = ac

        # Ensure ambiguity is bool
        final_result["ambiguity"] = bool(amb_result.get("human_review_required", False))

        # Clamp confidence
        conf = float(final_result.get("confidence", 0.5))
        final_result["confidence"] = max(0.0, min(1.0, conf))

        logger.info(
            "=== Pipeline DONE | confidence=%.2f | ambiguity=%s ===",
            final_result["confidence"],
            final_result["ambiguity"],
        )
        return final_result
