"""
Failure IQ Dataset Loader.

Simulates an IBM-style industrial sensor failure dataset with realistic
synthetic records covering common industrial failure modes.
"""

import random
import uuid
from typing import Dict, List

from utils.logger import setup_logger

logger = setup_logger(__name__)

# ── Synthetic dataset configuration ─────────────────────────────────────────

EQUIPMENT_TYPES = [
    "Centrifugal Pump", "Induction Motor", "Hydraulic Press",
    "Conveyor Belt", "Compressor", "Heat Exchanger",
    "Gearbox", "Turbine", "Cooling Tower", "Valve Assembly",
]

FAILURE_MODES = [
    "Bearing Wear", "Cavitation", "Misalignment", "Imbalance",
    "Overheating", "Corrosion", "Fatigue Crack", "Seal Failure",
    "Lubrication Failure", "Electrical Fault", "Vibration Anomaly",
    "Pressure Drop", "Flow Restriction", "Thermal Degradation",
]

SENSOR_COLS = [
    "temperature_celsius", "vibration_mm_s", "pressure_bar",
    "flow_rate_lpm", "rpm", "current_amps", "voltage_v",
    "noise_db", "humidity_pct", "oil_viscosity_cst",
]

LOCATIONS = ["Plant A", "Plant B", "Plant C", "Workshop 1", "Workshop 2"]
SEVERITIES = ["Low", "Medium", "High", "Critical"]
ACTIONS = [
    "Schedule preventive maintenance",
    "Replace bearing immediately",
    "Realign shaft coupling",
    "Flush and refill lubrication system",
    "Inspect and tighten electrical connections",
    "Calibrate pressure sensor",
    "Reduce operating load by 20%",
    "Conduct vibration analysis",
    "Check cooling system integrity",
    "Perform seal inspection",
]


def _sensor_value(col: str) -> float:
    ranges = {
        "temperature_celsius": (40, 120),
        "vibration_mm_s": (0.5, 15.0),
        "pressure_bar": (1.0, 30.0),
        "flow_rate_lpm": (5.0, 500.0),
        "rpm": (500, 3600),
        "current_amps": (2.0, 80.0),
        "voltage_v": (200.0, 440.0),
        "noise_db": (50, 110),
        "humidity_pct": (20, 95),
        "oil_viscosity_cst": (10, 220),
    }
    lo, hi = ranges.get(col, (0.0, 100.0))
    return round(random.uniform(lo, hi), 2)


class FailureIQLoader:
    """
    Generates a synthetic IBM-style Failure IQ dataset and converts each
    record into a structured text document ready for embedding.
    """

    def __init__(self, n_records: int = 400):
        self.n_records = n_records

    def _generate_records(self) -> List[Dict]:
        records = []
        for _ in range(self.n_records):
            failure = random.choice(FAILURE_MODES)
            equipment = random.choice(EQUIPMENT_TYPES)
            severity = random.choice(SEVERITIES)
            location = random.choice(LOCATIONS)
            action = random.choice(ACTIONS)

            sensor_data = {col: _sensor_value(col) for col in SENSOR_COLS}

            # Inject realistic anomaly signals based on failure mode
            if "Bearing" in failure:
                sensor_data["vibration_mm_s"] = round(random.uniform(8.0, 15.0), 2)
                sensor_data["temperature_celsius"] = round(random.uniform(85, 120), 2)
            elif "Cavitation" in failure:
                sensor_data["pressure_bar"] = round(random.uniform(0.5, 2.0), 2)
                sensor_data["noise_db"] = round(random.uniform(95, 110), 2)
            elif "Overheating" in failure:
                sensor_data["temperature_celsius"] = round(random.uniform(100, 120), 2)
                sensor_data["current_amps"] = round(random.uniform(65, 80), 2)
            elif "Electrical" in failure:
                sensor_data["voltage_v"] = round(random.uniform(200, 220), 2)
                sensor_data["current_amps"] = round(random.uniform(70, 80), 2)

            records.append({
                "id": str(uuid.uuid4())[:8],
                "equipment": equipment,
                "failure_mode": failure,
                "severity": severity,
                "location": location,
                "recommended_action": action,
                **sensor_data,
            })
        return records

    def _record_to_text(self, rec: Dict) -> str:
        """Convert a record dict to a human-readable text document."""
        sensors = "\n".join(
            f"  • {k.replace('_', ' ').title()}: {rec[k]}"
            for k in SENSOR_COLS
        )
        return (
            f"Equipment: {rec['equipment']} | ID: {rec['id']}\n"
            f"Location: {rec['location']}\n"
            f"Failure Mode: {rec['failure_mode']}\n"
            f"Severity: {rec['severity']}\n"
            f"Sensor Readings:\n{sensors}\n"
            f"Recommended Action: {rec['recommended_action']}"
        )

    def load(self) -> List[Dict]:
        """
        Generate synthetic records and return as document dicts.
        Each dict: {content: str, metadata: dict}
        """
        logger.info("Generating %d synthetic Failure IQ records …", self.n_records)
        records = self._generate_records()
        docs = []
        for rec in records:
            docs.append({
                "content": self._record_to_text(rec),
                "metadata": {
                    "source": "failure_iq",
                    "equipment": rec["equipment"],
                    "failure_mode": rec["failure_mode"],
                    "severity": rec["severity"],
                },
            })
        logger.info("Generated %d Failure IQ documents.", len(docs))
        return docs
