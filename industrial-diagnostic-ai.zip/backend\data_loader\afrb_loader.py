"""
AFRB Dataset Loader.

Reads an AFRB CSV file (Asset Failure Root-cause Behaviour),
handles missing values, and converts rows to structured text documents.
A sample CSV is bundled in data/afrb_sample.csv.
"""

import re
from pathlib import Path
from typing import Dict, List

import numpy as np
import pandas as pd

from utils.logger import setup_logger

logger = setup_logger(__name__)


class AFRBLoader:
    """
    Loads an AFRB dataset from CSV and converts to document dicts.
    Gracefully handles varying column sets.
    """

    def __init__(self, csv_path: str):
        self.csv_path = Path(csv_path)
        if not self.csv_path.exists():
            raise FileNotFoundError(f"AFRB CSV not found at: {self.csv_path}")

    # ── Preprocessing ────────────────────────────────────────────────────────

    def _preprocess(self, df: pd.DataFrame) -> pd.DataFrame:
        """Clean and normalise the dataframe."""
        # Standardise column names
        df.columns = [
            re.sub(r"[^a-z0-9_]", "_", c.lower().strip())
            for c in df.columns
        ]

        # Drop fully empty columns/rows
        df = df.dropna(axis=1, how="all").dropna(axis=0, how="all")

        # Fill numeric NaN with column median; categorical with 'Unknown'
        for col in df.columns:
            if df[col].dtype in [np.float64, np.int64]:
                df[col] = df[col].fillna(df[col].median())
            else:
                df[col] = df[col].fillna("Unknown").astype(str).str.strip()

        logger.info("Preprocessed AFRB: %d rows × %d cols", len(df), len(df.columns))
        return df

    def _row_to_text(self, row: pd.Series, columns: List[str]) -> str:
        """Convert a dataframe row to a readable text document."""
        parts = []
        for col in columns:
            val = row[col]
            if str(val).strip().lower() not in ("", "nan", "unknown"):
                label = col.replace("_", " ").title()
                parts.append(f"{label}: {val}")
        return "\n".join(parts) if parts else "No data."

    # ── Public ───────────────────────────────────────────────────────────────

    def load(self) -> List[Dict]:
        """
        Load CSV → preprocess → convert to document list.
        Returns: [{content: str, metadata: dict}, ...]
        """
        logger.info("Loading AFRB CSV from: %s", self.csv_path)
        df = pd.read_csv(self.csv_path, low_memory=False)
        df = self._preprocess(df)

        cols = list(df.columns)
        docs = []

        for _, row in df.iterrows():
            content = self._row_to_text(row, cols)
            # Build metadata from first few meaningful columns
            meta: Dict = {"source": "afrb"}
            for key in ["asset_id", "asset", "failure_mode", "fault_type",
                        "severity", "component", "system"]:
                if key in df.columns:
                    meta[key] = str(row[key])

            docs.append({"content": content, "metadata": meta})

        logger.info("Loaded %d AFRB documents.", len(docs))
        return docs
