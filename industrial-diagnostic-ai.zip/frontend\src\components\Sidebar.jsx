import { useState, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import {
  Database, Activity, RefreshCw, Upload, ArrowLeft,
  CheckCircle2, XCircle, Loader2, ChevronRight
} from 'lucide-react'

const DATASET_LABELS = {
  failure_iq: { label: 'Failure IQ', icon: Activity, color: 'text-indigo-400' },
  afrb:       { label: 'AFRB',       icon: Database,  color: 'text-emerald-400' },
}

export default function Sidebar({
  dataset, meta, dataStatus, onLoadDataset, onSwitchDataset,
  fileInputRef, onFileUpload, uploadLoading
}) {
  const navigate = useNavigate()
  const [collapsed, setCollapsed] = useState(false)
  const { icon: Icon, color } = DATASET_LABELS[dataset] || DATASET_LABELS.failure_iq

  if (collapsed) {
    return (
      <div className="w-12 flex flex-col items-center py-4 border-r border-white/5 bg-[var(--bg-secondary)]/60 backdrop-blur-sm">
        <button
          onClick={() => setCollapsed(false)}
          className="p-2 rounded-lg hover:bg-white/10 text-[var(--text-muted)] hover:text-white transition-colors"
          title="Expand sidebar"
        >
          <ChevronRight size={18} />
        </button>
      </div>
    )
  }

  return (
    <motion.aside
      initial={{ x: -20, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      className="w-72 flex-shrink-0 border-r border-white/5 bg-[var(--bg-secondary)]/60 backdrop-blur-sm flex flex-col"
    >
      {/* Header */}
      <div className="p-5 border-b border-white/5">
        <div className="flex items-center justify-between mb-1">
          <span className="text-xs text-[var(--text-muted)] uppercase tracking-widest">Active Dataset</span>
          <button
            onClick={() => setCollapsed(true)}
            className="p-1 rounded hover:bg-white/10 text-[var(--text-muted)] transition-colors"
            title="Collapse"
          >
            <ChevronRight size={14} className="rotate-180" />
          </button>
        </div>
        <div className="flex items-center gap-2 mt-2">
          <div className={`w-8 h-8 rounded-lg ${dataset === 'failure_iq' ? 'bg-indigo-500/20' : 'bg-emerald-500/20'} flex items-center justify-center`}>
            <Icon size={16} className={color} />
          </div>
          <div>
            <p className="text-white font-semibold text-sm">{meta.label}</p>
            <p className="text-xs text-[var(--text-muted)]">
              {dataStatus.checking
                ? 'Checking…'
                : dataStatus.loaded
                  ? '✓ Index Ready'
                  : '✗ Not Loaded'}
            </p>
          </div>
        </div>
      </div>

      {/* Status */}
      <div className="p-5 border-b border-white/5">
        <div className={`flex items-center gap-2 px-3 py-2 rounded-xl text-sm ${
          dataStatus.loaded ? 'bg-emerald-500/10 text-emerald-400' : 'bg-amber-500/10 text-amber-400'
        }`}>
          {dataStatus.loaded
            ? <CheckCircle2 size={14} />
            : <XCircle size={14} />}
          <span className="text-xs font-medium">
            {dataStatus.loaded ? 'FAISS index active' : 'Dataset not loaded'}
          </span>
        </div>
      </div>

      {/* Actions */}
      <div className="p-5 space-y-3 border-b border-white/5">
        <p className="text-xs text-[var(--text-muted)] uppercase tracking-widest mb-2">Actions</p>

        {/* Load / Reload */}
        <button
          id="load-dataset-btn"
          onClick={onLoadDataset}
          disabled={uploadLoading}
          className="w-full flex items-center gap-2 px-4 py-2.5 rounded-xl bg-primary-600/30 hover:bg-primary-600/50 border border-primary-500/30 text-primary-300 text-sm transition-all disabled:opacity-50"
        >
          {uploadLoading ? <Loader2 size={15} className="animate-spin" /> : <RefreshCw size={15} />}
          {dataStatus.loaded ? 'Reload Dataset' : 'Load Dataset'}
        </button>

        {/* CSV Upload (AFRB only) */}
        {dataset === 'afrb' && (
          <>
            <input
              ref={fileInputRef}
              type="file"
              accept=".csv"
              className="hidden"
              id="csv-file-input"
              onChange={(e) => e.target.files?.[0] && onFileUpload(e.target.files[0])}
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={uploadLoading}
              className="w-full flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/40 border border-emerald-500/30 text-emerald-300 text-sm transition-all disabled:opacity-50"
            >
              <Upload size={15} />
              Upload CSV
            </button>
          </>
        )}

        {/* Switch Dataset */}
        <button
          onClick={onSwitchDataset}
          className="w-full flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-[var(--text-muted)] hover:text-white text-sm transition-all"
        >
          <ArrowLeft size={15} />
          Switch Dataset
        </button>
      </div>

      {/* Agent list */}
      <div className="p-5 flex-1">
        <p className="text-xs text-[var(--text-muted)] uppercase tracking-widest mb-3">Active Agents</p>
        <div className="space-y-2">
          {[
            { label: 'Diagnostic Expert', emoji: '🧠' },
            { label: 'Pattern Recognition', emoji: '🔍' },
            { label: 'Aggressive Decision', emoji: '⚡' },
            { label: 'Verification Analyst', emoji: '✅' },
            { label: 'Ambiguity Detection', emoji: '🎯' },
            { label: 'Human Coordinator', emoji: '🏁' },
          ].map(({ label, emoji }) => (
            <div key={label} className="flex items-center gap-2 text-xs text-[var(--text-muted)]">
              <span>{emoji}</span>
              <span>{label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Footer */}
      <div className="p-5 border-t border-white/5">
        <p className="text-[10px] text-[var(--text-muted)] text-center">
          Industrial Diagnostic AI v1.0
          <br />RAG · FAISS · Multi-Agent
        </p>
      </div>
    </motion.aside>
  )
}
