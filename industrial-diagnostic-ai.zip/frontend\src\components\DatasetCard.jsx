import { motion } from 'framer-motion'
import { ArrowRight, CheckCircle2 } from 'lucide-react'

const COLOR_MAP = {
  indigo: {
    border: 'border-indigo-500/40 hover:border-indigo-400',
    icon: 'bg-indigo-500/20 text-indigo-400',
    btn: 'bg-indigo-600 hover:bg-indigo-500',
    tag: 'bg-indigo-500/15 text-indigo-300 border-indigo-500/30',
    glow: 'hover:shadow-[0_0_40px_rgba(99,102,241,0.2)]',
  },
  emerald: {
    border: 'border-emerald-500/40 hover:border-emerald-400',
    icon: 'bg-emerald-500/20 text-emerald-400',
    btn: 'bg-emerald-600 hover:bg-emerald-500',
    tag: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30',
    glow: 'hover:shadow-[0_0_40px_rgba(16,185,129,0.2)]',
  },
}

export default function DatasetCard({ id, title, subtitle, description, icon: Icon, accentColor, tags, onSelect }) {
  const c = COLOR_MAP[accentColor] || COLOR_MAP.indigo

  return (
    <motion.div
      whileHover={{ scale: 1.02, y: -4 }}
      whileTap={{ scale: 0.98 }}
      transition={{ type: 'spring', stiffness: 300, damping: 20 }}
      className={`glass-card p-8 cursor-pointer transition-all duration-300 ${c.border} ${c.glow} group`}
      onClick={() => onSelect(id)}
      role="button"
      tabIndex={0}
      id={`dataset-card-${id}`}
      aria-label={`Select ${title}`}
      onKeyDown={(e) => e.key === 'Enter' && onSelect(id)}
    >
      {/* Icon + Title */}
      <div className={`w-14 h-14 rounded-2xl ${c.icon} flex items-center justify-center mb-5 group-hover:scale-110 transition-transform`}>
        <Icon size={28} />
      </div>

      <h3 className="text-xl font-bold text-white mb-1">{title}</h3>
      <p className="text-sm font-medium text-[var(--text-muted)] mb-4">{subtitle}</p>
      <p className="text-sm text-[var(--text-muted)] leading-relaxed mb-6">{description}</p>

      {/* Tags */}
      <div className="flex flex-wrap gap-2 mb-6">
        {tags.map((tag) => (
          <span
            key={tag}
            className={`text-xs px-2.5 py-1 rounded-full border ${c.tag}`}
          >
            {tag}
          </span>
        ))}
      </div>

      {/* CTA */}
      <button
        className={`w-full flex items-center justify-center gap-2 py-3 rounded-xl text-white font-semibold text-sm ${c.btn} transition-colors`}
      >
        Select Dataset
        <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
      </button>
    </motion.div>
  )
}
