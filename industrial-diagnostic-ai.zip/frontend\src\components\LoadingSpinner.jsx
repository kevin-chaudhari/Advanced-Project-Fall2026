import { motion } from 'framer-motion'
import { Cpu } from 'lucide-react'

const AGENT_STEPS = [
  'RAG Retrieval',
  'Pattern Recognition',
  'Aggressive Decision',
  'Diagnostic Expert',
  'Verification Analyst',
  'Ambiguity Detection',
  'Final Synthesis',
]

export default function LoadingSpinner() {
  return (
    <div className="chat-bubble-ai px-6 py-5 inline-block max-w-sm">
      <div className="flex items-center gap-3 mb-4">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1.5, repeat: Infinity, ease: 'linear' }}
        >
          <Cpu size={18} className="text-primary-400" />
        </motion.div>
        <span className="text-sm font-semibold text-white">Running Agent Pipeline…</span>
      </div>

      <div className="space-y-2">
        {AGENT_STEPS.map((step, i) => (
          <motion.div
            key={step}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.3, repeat: Infinity, repeatDelay: AGENT_STEPS.length * 0.3 + 1 }}
            className="flex items-center gap-2"
          >
            <motion.div
              animate={{ scale: [1, 1.3, 1] }}
              transition={{ delay: i * 0.3, duration: 0.4, repeat: Infinity, repeatDelay: AGENT_STEPS.length * 0.3 + 1 }}
              className="w-1.5 h-1.5 rounded-full bg-primary-400"
            />
            <span className="text-xs text-[var(--text-muted)]">{step}</span>
          </motion.div>
        ))}
      </div>

      <div className="flex gap-1 mt-4">
        {[0, 1, 2].map((i) => (
          <motion.div
            key={i}
            animate={{ opacity: [0.3, 1, 0.3] }}
            transition={{ duration: 1.2, delay: i * 0.2, repeat: Infinity }}
            className="w-1.5 h-1.5 rounded-full bg-primary-400"
          />
        ))}
      </div>
    </div>
  )
}
