import { useEffect, useRef } from 'react'
import { Gauge } from 'lucide-react'

function getColor(pct) {
  if (pct >= 75) return { bar: 'from-emerald-500 to-emerald-400', text: 'text-emerald-400', label: 'High Confidence' }
  if (pct >= 50) return { bar: 'from-yellow-500 to-amber-400', text: 'text-amber-400', label: 'Moderate Confidence' }
  return { bar: 'from-red-500 to-red-400', text: 'text-red-400', label: 'Low Confidence' }
}

export default function ConfidenceBar({ confidence }) {
  const pct = Math.round((confidence || 0) * 100)
  const { bar, text, label } = getColor(pct)
  const barRef = useRef(null)

  useEffect(() => {
    if (barRef.current) {
      barRef.current.style.setProperty('--target-width', `${pct}%`)
      barRef.current.classList.add('progress-fill')
    }
  }, [pct])

  return (
    <div className="glass-card p-5">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Gauge size={16} className={text} />
          <span className="text-sm font-semibold text-white">Confidence Score</span>
        </div>
        <div className="flex items-center gap-2">
          <span className={`text-2xl font-bold font-mono ${text}`}>{pct}%</span>
          <span className={`text-xs px-2 py-0.5 rounded-full border ${
            pct >= 75 ? 'badge-success' : pct >= 50 ? 'badge-warn' : 'badge-danger'
          }`}>
            {label}
          </span>
        </div>
      </div>

      {/* Track */}
      <div className="h-3 rounded-full bg-white/5 overflow-hidden">
        <div
          ref={barRef}
          style={{ width: 0 }}
          className={`h-full rounded-full bg-gradient-to-r ${bar}`}
        />
      </div>

      <p className="text-xs text-[var(--text-muted)] mt-2">
        Calibrated confidence from the Ambiguity Detection Agent across all 6-agent outputs.
      </p>
    </div>
  )
}
