"""
Human Review Coordinator Agent.

Synthesises all previous agent outputs into a final, human-readable
diagnostic report that is clear, actionable, and structured.
"""

import json
from typing import Any, Dict, List

from agents.base_agent import BaseAgent


class HumanReviewCoordinatorAgent(BaseAgent):

    @property
    def role(self) -> str:
        return "Human Review Coordinator"

    @property
    def goal(self) -> str:
        return (
            "Synthesise all agent outputs into a final, clear, actionable "
            "industrial diagnostic report ready for human review."
        )

    def build_prompt(self, question: str, context: str, extra: Dict) -> str:
        def safe_dump(key: str) -> str:
            v = extra.get(key, {})
            return json.dumps(v, indent=2) if v else "Not available"

        return f"""
You are the Human Review Coordinator — the final stage of an industrial multi-agent
AI diagnostic system. You synthesise all agent outputs into a definitive report.

ORIGINAL QUESTION: {question}

EVIDENCE CONTEXT:
{context}

AGENT INPUTS:
--- Diagnostic Expert ---
{safe_dump("diagnostic_expert")}

--- Pattern Recognition ---
{safe_dump("pattern_agent")}

--- Aggressive Decision ---
{safe_dump("aggressive_agent")}

--- Verification Analyst ---
{safe_dump("verification")}

--- Ambiguity Detection ---
{safe_dump("ambiguity")}

INSTRUCTIONS:
1. Produce a final, definitive diagnosis based on ALL agent inputs.
2. Write 4–6 clear reasoning steps (numbered).
3. List 3–5 pieces of supporting evidence from the context.
4. Summarise each agent's contribution in one sentence.
5. Use the ambiguity agent's confidence as the final confidence score.
6. Set human_review_required from the ambiguity agent's output.

Respond ONLY with valid JSON matching this EXACT structure:
{{
  "final_diagnosis": "...",
  "confidence": 0.0,
  "reasoning": ["Step 1: ...", "Step 2: ...", "Step 3: ...", "Step 4: ..."],
  "supporting_evidence": ["evidence1", "evidence2", "evidence3"],
  "agent_contributions": {{
    "diagnostic_expert": "...",
    "pattern_agent": "...",
    "aggressive_agent": "...",
    "verification": "...",
    "ambiguity": "...",
    "final_decision": "..."
  }},
  "ambiguity": false
}}
"""

    async def run(self, question: str, context: str, extra: Dict = None) -> Dict[str, Any]:
        result = await super().run(question, context, extra)

        # Ensure every required field exists with a sensible default
        result.setdefault("final_diagnosis", "Diagnosis could not be determined.")
        result.setdefault("confidence", extra.get("ambiguity", {}).get("overall_confidence", 0.5))
        result.setdefault("reasoning", ["Insufficient data for detailed reasoning."])
        result.setdefault("supporting_evidence", [])
        result.setdefault("ambiguity", False)
        result.setdefault(
            "agent_contributions",
            {
                "diagnostic_expert": "Analysis performed.",
                "pattern_agent": "Patterns identified.",
                "aggressive_agent": "Rapid decision made.",
                "verification": "Outputs verified.",
                "ambiguity": "Confidence assessed.",
                "final_decision": result["final_diagnosis"],
            },
        )
        return result
