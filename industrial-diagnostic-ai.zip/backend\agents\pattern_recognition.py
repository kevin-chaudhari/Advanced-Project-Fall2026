"""
Pattern Recognition Agent.

Uses FAISS top-k similarity results to identify recurring failure patterns
and surface the most relevant historical cases.
"""

from typing import Any, Dict, List

from agents.base_agent import BaseAgent


class PatternRecognitionAgent(BaseAgent):

    @property
    def role(self) -> str:
        return "Pattern Recognition Agent"

    @property
    def goal(self) -> str:
        return (
            "Identify recurring failure patterns and anomalies from FAISS "
            "similarity search results and historical sensor data."
        )

    def build_prompt(self, question: str, context: str, extra: Dict) -> str:
        scores = extra.get("retrieval_scores", [])
        score_text = ", ".join(f"{s:.3f}" for s in scores) if scores else "N/A"

        return f"""
You are a pattern recognition specialist for industrial equipment diagnostics.
You excel at identifying failure signatures, trends, and recurring anomalies.

QUESTION: {question}

TOP-K SIMILAR CASES (semantic search results):
{context}

RETRIEVAL SIMILARITY SCORES: [{score_text}]

INSTRUCTIONS:
1. Identify the top recurring patterns across the retrieved cases.
2. Note any anomalous sensor readings that stand out.
3. Detect temporal or operational trends if visible.
4. Link patterns to known failure signatures.

Respond ONLY with valid JSON:
{{
  "patterns_identified": ["pattern1", "pattern2"],
  "anomalies": ["anomaly1"],
  "dominant_failure_signature": "...",
  "trend_analysis": "...",
  "confidence": 0.0
}}
"""

    async def run(self, question: str, context: str, extra: Dict = None) -> Dict[str, Any]:
        result = await super().run(question, context, extra)
        result.setdefault("patterns_identified", [])
        result.setdefault("anomalies", [])
        result.setdefault("dominant_failure_signature", "Unknown pattern.")
        result.setdefault("trend_analysis", "Insufficient data for trend analysis.")
        result.setdefault("confidence", 0.5)
        return result
