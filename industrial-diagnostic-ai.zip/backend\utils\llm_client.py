"""
LLM client — supports Ollama (local) and OpenAI-compatible APIs.
Configured via environment variables.
"""

import json
import os
import re
import time
from typing import Any, Dict, Optional

import httpx

from utils.logger import setup_logger

logger = setup_logger(__name__)


class LLMClient:
    """Unified LLM client supporting Ollama and OpenAI backends."""

    def __init__(self):
        self.provider = os.getenv("LLM_PROVIDER", "ollama").lower()
        self.ollama_base = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
        self.ollama_model = os.getenv("OLLAMA_MODEL", "llama3")
        self.openai_base = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
        self.openai_model = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
        self.openai_key = os.getenv("OPENAI_API_KEY", "")
        self.timeout = 120.0

    async def generate(self, prompt: str, system: str = "") -> str:
        """
        Generate a text response from the configured LLM.
        Returns raw text; JSON parsing is the caller's responsibility.
        """
        if self.provider == "openai":
            return await self._openai_generate(prompt, system)
        return await self._ollama_generate(prompt, system)

    async def _ollama_generate(self, prompt: str, system: str) -> str:
        """Call Ollama /api/generate endpoint."""
        full_prompt = f"{system}\n\n{prompt}" if system else prompt
        payload = {
            "model": self.ollama_model,
            "prompt": full_prompt,
            "stream": False,
            "options": {"temperature": 0.2, "num_predict": 1024},
        }

        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.post(f"{self.ollama_base}/api/generate", json=payload)
                resp.raise_for_status()
                data = resp.json()
                return data.get("response", "")
        except httpx.ConnectError:
            logger.warning("Ollama not reachable — using fallback mock response.")
            return self._mock_response(prompt)
        except Exception as exc:
            logger.error("Ollama error: %s", exc)
            return self._mock_response(prompt)

    async def _openai_generate(self, prompt: str, system: str) -> str:
        """Call OpenAI-compatible /chat/completions endpoint."""
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        headers = {
            "Authorization": f"Bearer {self.openai_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": self.openai_model,
            "messages": messages,
            "temperature": 0.2,
            "max_tokens": 1024,
        }

        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.post(
                    f"{self.openai_base}/chat/completions",
                    json=payload,
                    headers=headers,
                )
                resp.raise_for_status()
                data = resp.json()
                return data["choices"][0]["message"]["content"]
        except Exception as exc:
            logger.error("OpenAI error: %s", exc)
            return self._mock_response(prompt)

    def _mock_response(self, prompt: str) -> str:
        """
        Deterministic fallback when no LLM is available.
        Returns a plausible JSON-formatted mock so the pipeline stays functional.
        """
        keywords = prompt.lower()
        if "vibration" in keywords:
            diag = "Mechanical imbalance or bearing wear detected in rotating equipment."
            confidence = 0.72
        elif "temperature" in keywords:
            diag = "Thermal anomaly detected. Possible coolant failure or overload condition."
            confidence = 0.68
        elif "pressure" in keywords:
            diag = "Abnormal pressure reading. Possible blockage or pump cavitation."
            confidence = 0.65
        elif "sensor" in keywords:
            diag = "Sensor signal degradation. Calibration or replacement recommended."
            confidence = 0.60
        else:
            diag = "Anomalous operational pattern detected. Further inspection advised."
            confidence = 0.55

        return json.dumps({
            "analysis": diag,
            "confidence": confidence,
            "evidence": [
                "Sensor data indicates deviation from normal operating range.",
                "Historical patterns suggest component fatigue.",
                "Maintenance logs show no recent calibration.",
            ],
            "hypothesis": diag,
            "decision": diag,
            "patterns": ["Irregular oscillation", "Elevated baseline readings"],
            "contradictions_removed": [],
            "conflicts": [],
            "final_diagnosis": diag,
            "reasoning_steps": [
                "Step 1: Retrieved relevant sensor history.",
                "Step 2: Compared against known fault signatures.",
                "Step 3: Evaluated multiple hypotheses.",
                "Step 4: Verified consistency across agents.",
                "Step 5: Produced final diagnosis.",
            ],
            "ambiguity_detected": False,
        })

    @staticmethod
    def extract_json(text: str) -> Dict[str, Any]:
        """
        Robustly extract the first JSON object from an LLM response string.
        Falls back to an empty dict on failure.
        """
        # Try direct parse first
        try:
            return json.loads(text.strip())
        except json.JSONDecodeError:
            pass

        # Try to find a JSON block inside markdown fences
        fenced = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.DOTALL)
        if fenced:
            try:
                return json.loads(fenced.group(1))
            except json.JSONDecodeError:
                pass

        # Try to find first {...} block
        brace_match = re.search(r"\{.*\}", text, re.DOTALL)
        if brace_match:
            try:
                return json.loads(brace_match.group())
            except json.JSONDecodeError:
                pass

        logger.warning("Could not extract JSON from LLM response; using empty dict.")
        return {}


# Singleton instance
llm_client = LLMClient()
