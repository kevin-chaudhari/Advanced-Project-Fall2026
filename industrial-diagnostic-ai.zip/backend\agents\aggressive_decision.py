"""
Aggressive Decision Agent.

Uses fast heuristic reasoning to generate a decisive, immediate diagnostic
conclusion without extensive deliberation — useful for time-critical decisions.
"""

from typing import Any, Dict

from agents.base_agent import BaseAgent


class AggressiveDecisionAgent(BaseAgent):

    @property
    def role(self) -> str:
        return "Aggressive Decision Agent"

    @property
    def goal(self) -> str:
        return (
            "Rapidly apply heuristic reasoning to produce an immediate, "
            "decisive diagnostic conclusion from sensor data and context."
        )

    def build_prompt(self, question: str, context: str, extra: Dict) -> str:
        return f"""
You are an aggressive, decisive industrial diagnostic AI. You make rapid, confident
decisions based on pattern recognition and heuristics. You do NOT over-deliberate.

QUESTION: {question}

SENSOR/FAILURE CONTEXT:
{context}

INSTRUCTIONS:
- Scan the context for the MOST OBVIOUS failure signature.
- Make ONE decisive diagnosis immediately.
- Provide 2–3 heuristic rules that led to your decision.
- Assign a confidence score.

Respond ONLY with valid JSON:
{{
  "decision": "...",
  "heuristic_rules": ["rule1", "rule2", "rule3"],
  "immediate_action": "...",
  "confidence": 0.0
}}
"""

    async def run(self, question: str, context: str, extra: Dict = None) -> Dict[str, Any]:
        result = await super().run(question, context, extra)
        result.setdefault("decision", "No immediate decision reached.")
        result.setdefault("heuristic_rules", [])
        result.setdefault("immediate_action", "Inspect equipment manually.")
        result.setdefault("confidence", 0.5)
        return result
