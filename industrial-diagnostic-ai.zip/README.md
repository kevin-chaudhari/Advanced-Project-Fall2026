# 🏭 Industrial Diagnostic AI System

A **production-ready, full-stack Multi-Agent AI** system for industrial equipment fault diagnosis. Built with **FastAPI + React + FAISS + RAG + 6-Agent Pipeline**.

---

## 📁 Project Structure

```
industrial-diagnostic-ai/
├── backend/
│   ├── main.py                         # FastAPI app entry point
│   ├── requirements.txt
│   ├── .env / .env.example
│   ├── data/
│   │   └── afrb_sample.csv             # Bundled AFRB sample dataset
│   ├── faiss_indexes/                  # Auto-created: persisted FAISS indexes
│   ├── uploads/                        # Auto-created: uploaded CSV files
│   ├── agents/
│   │   ├── __init__.py
│   │   ├── base_agent.py               # Abstract base agent
│   │   ├── diagnostic_expert.py        # Agent 1: Generates ≥3 hypotheses
│   │   ├── aggressive_decision.py      # Agent 2: Fast heuristic decision
│   │   ├── pattern_recognition.py      # Agent 3: FAISS top-k pattern analysis
│   │   ├── verification_analyst.py     # Agent 4: Cross-validates outputs
│   │   ├── ambiguity_detection.py      # Agent 5: Confidence scoring
│   │   ├── human_review_coordinator.py # Agent 6: Final synthesis
│   │   └── orchestrator.py             # Pipeline controller
│   ├── rag/
│   │   ├── __init__.py
│   │   ├── embedder.py                 # SentenceTransformer wrapper
│   │   ├── faiss_store.py              # Dual FAISS index manager
│   │   └── retriever.py                # Context formatter
│   ├── data_loader/
│   │   ├── __init__.py
│   │   ├── failure_iq_loader.py        # Synthetic IBM-style sensor data
│   │   └── afrb_loader.py              # CSV loader with preprocessing
│   ├── models/
│   │   ├── __init__.py
│   │   └── schemas.py                  # Pydantic request/response models
│   └── utils/
│       ├── __init__.py
│       ├── logger.py                   # Structured logging
│       └── llm_client.py               # Ollama/OpenAI unified client
│
└── frontend/
    ├── package.json
    ├── vite.config.js
    ├── tailwind.config.js
    ├── postcss.config.js
    ├── index.html
    └── src/
        ├── main.jsx
        ├── App.jsx
        ├── index.css                   # Global styles (glassmorphism, animations)
        ├── pages/
        │   ├── LandingPage.jsx         # Dataset selection + pipeline overview
        │   └── ChatPage.jsx            # Chat interface
        ├── components/
        │   ├── DatasetCard.jsx         # Animated dataset selection card
        │   ├── ChatMessage.jsx         # User/assistant/error message renderer
        │   ├── DiagnosisCard.jsx       # Structured AI response card
        │   ├── ConfidenceBar.jsx       # Animated progress bar
        │   ├── ReasoningAccordion.jsx  # Expandable reasoning steps
        │   ├── AgentContributions.jsx  # Per-agent accordion
        │   ├── LoadingSpinner.jsx      # Animated pipeline spinner
        │   └── Sidebar.jsx             # Dataset controls sidebar
        └── services/
            └── api.js                  # Axios API layer
```

---

## ⚙️ Backend Setup

### Prerequisites
- Python 3.10+
- pip
- (Optional) [Ollama](https://ollama.ai) with `llama3` model for local LLM

### 1. Install Dependencies

```bash
cd backend
pip install -r requirements.txt
```

### 2. Configure Environment

```bash
# Copy example .env (already created with defaults)
cp .env.example .env
```

Edit `.env` to choose your LLM provider:

```env
# Option A: Local Ollama (default, no API key needed)
LLM_PROVIDER=ollama
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=llama3

# Option B: OpenAI
LLM_PROVIDER=openai
OPENAI_API_KEY=sk-your-key-here
OPENAI_MODEL=gpt-4o-mini
```

### 3. (Optional) Pull Ollama Model

```bash
ollama pull llama3
```

### 4. Start the Backend

```bash
cd backend
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

The server auto-loads both datasets on startup. Visit:
- **API Docs**: http://localhost:8000/docs
- **Health Check**: http://localhost:8000/health

---

## 🖥️ Frontend Setup

### Prerequisites
- Node.js 18+
- npm

### 1. Install Dependencies

```bash
cd frontend
npm install
```

### 2. Start Development Server

```bash
npm run dev
```

Open **http://localhost:5173** in your browser.

---

## 🚀 Quick Start (Full System)

```bash
# Terminal 1: Backend
cd backend
pip install -r requirements.txt
uvicorn main:app --reload

# Terminal 2: Frontend
cd frontend
npm install
npm run dev
```

---

## 🔌 API Reference

### `GET /health`
Check system status.
```json
{
  "status": "ok",
  "failure_iq_loaded": true,
  "afrb_loaded": true,
  "message": "Industrial Diagnostic AI System is running"
}
```

### `POST /load-data?dataset_type=failure_iq`
Load Failure IQ dataset (auto-generated, no file needed).

### `POST /load-data?dataset_type=afrb`
Load AFRB dataset. Optionally attach a CSV file as `multipart/form-data`.

### `POST /query`
Main diagnostic endpoint.

**Request:**
```json
{
  "question": "Why is vibration increasing in pump A?",
  "dataset_type": "failure_iq",
  "top_k": 5
}
```

**Response:**
```json
{
  "final_diagnosis": "Bearing wear detected — mechanical imbalance in rotating shaft.",
  "confidence": 0.82,
  "reasoning": [
    "Step 1: Retrieved 5 relevant sensor records from FAISS.",
    "Step 2: Pattern agent identified elevated vibration (11+ mm/s) as key signal.",
    "Step 3: Diagnostic expert generated 3 hypotheses; bearing wear scored highest (0.87).",
    "Step 4: Verification analyst confirmed consensus across all parallel agents.",
    "Step 5: Ambiguity agent found no significant conflicts; confidence confirmed at 82%."
  ],
  "supporting_evidence": [
    "Sensor data shows vibration at 11.2 mm/s (normal: <5 mm/s).",
    "Temperature elevated to 92°C on bearing housing.",
    "Similar failure pattern in 12 historical records."
  ],
  "agent_contributions": {
    "diagnostic_expert": "Generated 3 hypotheses; bearing wear primary (score: 0.87).",
    "pattern_agent": "Identified dominant vibration signature matching bearing degradation.",
    "aggressive_agent": "Rapid decision: Replace bearing — high vibration + heat signature.",
    "verification": "All agents agree on mechanical failure. No contradictions found.",
    "ambiguity": "Low ambiguity. Confidence 82%. No human review required.",
    "final_decision": "Bearing wear detected — mechanical imbalance in rotating shaft."
  },
  "ambiguity": false,
  "dataset_used": "failure_iq",
  "retrieved_context_count": 5
}
```

---

## 🧠 Multi-Agent Pipeline

```
User Query
    ↓
RAG Retrieval (FAISS top-k semantic search)
    ↓
┌─────────────────────────────────────────────────────┐
│  PHASE 1 — Parallel Execution (asyncio.gather)      │
│  • Pattern Recognition Agent (FAISS patterns)       │
│  • Aggressive Decision Agent (heuristics)           │
│  • Diagnostic Expert Agent (≥3 hypotheses)          │
└─────────────────────────────────────────────────────┘
    ↓
Phase 2 — Verification Analyst (removes contradictions)
    ↓
Phase 3 — Ambiguity Detection Agent (confidence scoring)
    ↓
Phase 4 — Human Review Coordinator (final JSON output)
```

---

## 🧪 Sample Test Queries

| Dataset | Query |
|---------|-------|
| Failure IQ | "Why is vibration increasing in pump A?" |
| Failure IQ | "Predict failure cause based on temperature spikes to 118°C" |
| Failure IQ | "What anomaly is detected in the sensor data?" |
| Failure IQ | "Is the bearing condition critical for this motor?" |
| Failure IQ | "What maintenance is recommended for the compressor?" |
| AFRB | "What is the root cause of gearbox failure?" |
| AFRB | "Which asset has the highest failure severity?" |
| AFRB | "How does seal failure affect pump performance?" |
| AFRB | "Predict failure from elevated vibration and temperature readings" |
| AFRB | "What maintenance action for bearing degradation?" |

---

## 📊 Understanding the Output

### Confidence Score
| Score | Meaning | Action |
|-------|---------|--------|
| 75–100% | High confidence | Follow recommendation directly |
| 50–74% | Moderate confidence | Verify with additional inspection |
| 0–49% | Low confidence | Human expert review recommended |

### Reasoning Steps
Numbered chronological steps showing how agents arrived at the conclusion.

### Agent Contributions
Each of the 6 agents contributes a one-sentence summary of its finding:
- 🧠 **Diagnostic Expert**: Evidence-scored hypotheses
- 🔍 **Pattern Recognition**: FAISS-identified failure signatures
- ⚡ **Aggressive Decision**: Heuristic fast-path decision
- ✅ **Verification Analyst**: Consensus & contradiction resolution
- 🎯 **Ambiguity Detection**: Uncertainty quantification
- 🏁 **Human Coordinator**: Synthesised final report

### Ambiguity Flag
If `true`, confidence is below threshold or major conflicts were detected. Manual review recommended.

---

## 🔧 LLM Configuration

### No LLM Available?
The system includes a **robust mock fallback** — it produces realistic, keyword-aware responses if neither Ollama nor OpenAI is reachable. The full pipeline still executes.

### Using Ollama (Recommended for local use)
```bash
# Install Ollama: https://ollama.ai
ollama pull llama3
# or for faster responses:
ollama pull mistral
```
Update `.env`: `OLLAMA_MODEL=mistral`

### Using OpenAI
```env
LLM_PROVIDER=openai
OPENAI_API_KEY=sk-...
OPENAI_MODEL=gpt-4o-mini
```

---

## 📦 Dependencies

### Backend
| Package | Purpose |
|---------|---------|
| fastapi | REST API framework |
| uvicorn | ASGI server |
| faiss-cpu | Vector similarity search |
| sentence-transformers | Embedding model (all-MiniLM-L6-v2) |
| pandas | Data loading and preprocessing |
| httpx | Async HTTP (LLM calls) |
| python-dotenv | Environment variable management |

### Frontend
| Package | Purpose |
|---------|---------|
| react 18 | UI framework |
| vite | Dev server and bundler |
| tailwindcss | Utility-first CSS |
| framer-motion | Animations |
| lucide-react | Icons |
| axios | HTTP client |
| react-router-dom | Client-side routing |

---

## 🗃️ AFRB CSV Format

Your CSV should include columns like (flexible — all columns are used):

```
asset_id, asset_name, failure_mode, fault_type, severity,
component, system, temperature_c, vibration_mms, pressure_bar,
flow_rate_lpm, operating_hours, last_maintenance_days, description
```

Missing values are handled automatically (numeric → median fill, text → "Unknown").

---

## 🏗️ Production Deployment Notes

1. Set `CORS_ORIGINS` to your production frontend domain
2. Use `gunicorn` with uvicorn workers: `gunicorn -k uvicorn.workers.UvicornWorker main:app`
3. Build frontend: `npm run build` and serve with nginx/CDN
4. Persist `faiss_indexes/` directory across restarts
5. Use environment secrets management for `OPENAI_API_KEY`
