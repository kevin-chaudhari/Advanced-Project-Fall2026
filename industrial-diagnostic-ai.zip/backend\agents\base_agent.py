"""
Base agent class — provides shared structure for all agents.
Each agent takes a question + context and returns a structured dict.
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List

from utils.llm_client import LLMClient, llm_client
from utils.logger import setup_logger


class BaseAgent(ABC):
    """Abstract base for all diagnostic agents."""

    def __init__(self):
        self.llm: LLMClient = llm_client
        self.logger = setup_logger(self.__class__.__name__)

    @property
    @abstractmethod
    def role(self) -> str:
        """Short agent role name."""
        ...

    @property
    @abstractmethod
    def goal(self) -> str:
        """What this agent aims to accomplish."""
        ...

    @abstractmethod
    def build_prompt(self, question: str, context: str, extra: Dict) -> str:
        """Build the agent-specific LLM prompt."""
        ...

    async def run(self, question: str, context: str, extra: Dict = None) -> Dict[str, Any]:
        """Execute the agent and return a parsed dict."""
        extra = extra or {}
        self.logger.info("[%s] Running …", self.role)
        prompt = self.build_prompt(question, context, extra)
        raw = await self.llm.generate(prompt, system=self._system_message())
        result = self.llm.extract_json(raw)
        self.logger.info("[%s] Done.", self.role)
        return result

    def _system_message(self) -> str:
        return (
            f"You are the {self.role}. Your goal: {self.goal}\n"
            "ALWAYS respond in valid JSON. Do not add prose outside the JSON object."
        )

    @staticmethod
    def format_context(docs: List[Dict]) -> str:
        if not docs:
            return "No relevant context found."
        parts = []
        for i, doc in enumerate(docs, 1):
            parts.append(f"[{i}] {doc.get('content', '')}")
        return "\n\n".join(parts)
