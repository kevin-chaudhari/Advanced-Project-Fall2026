import { useState } from 'react'
import { motion } from 'framer-motion'
import { CheckCircle2, AlertTriangle, FileText, Lightbulb } from 'lucide-react'
import ConfidenceBar from './ConfidenceBar'
import ReasoningAccordion from './ReasoningAccordion'
import AgentContributions from './AgentContributions'

export default function DiagnosisCard({ result }) {
  const {
    final_diagnosis,
    confidence = 0,
    reasoning = [],
    supporting_evidence = [],
    agent_contributions,
    ambiguity = false,
    dataset_used,
    retrieved_context_count = 0,
  } = result

  const confidencePct = Math.round(confidence * 100)
  const isHigh = confidencePct >= 75
  const isMed = confidencePct >= 50 && confidencePct < 75

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4 w-full"
    >
      {/* ── Final Diagnosis ─────────────────────────────────────────────── */}
      <div className={`glass-card p-5 border-l-4 ${
        ambiguity ? 'border-l-amber-500' : isHigh ? 'border-l-emerald-500' : isMed ? 'border-l-yellow-500' : 'border-l-red-500'
      }`}>
        <div className="flex items-start gap-3">
          <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
            isHigh ? 'bg-emerald-500/20' : isMed ? 'bg-yellow-500/20' : 'bg-red-500/20'
          }`}>
            {ambiguity
              ? <AlertTriangle size={16} className="text-amber-400" />
              : <CheckCircle2 size={16} className={isHigh ? 'text-emerald-400' : 'text-yellow-400'} />
            }
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 flex-wrap mb-2">
              <span className="text-xs font-semibold uppercase tracking-widest text-[var(--text-muted)]">Final Diagnosis</span>
              {ambiguity && (
                <span className="badge-warn text-xs px-2 py-0.5 rounded-full">⚠ Ambiguous — Human Review Advised</span>
              )}
              {dataset_used && (
                <span className="badge-info text-xs px-2 py-0.5 rounded-full capitalize">{dataset_used.replace('_', ' ')}</span>
              )}
            </div>
            <p className="text-white font-semibold text-base leading-relaxed">{final_diagnosis}</p>
          </div>
        </div>
      </div>

      {/* ── Confidence Score ─────────────────────────────────────────────── */}
      <ConfidenceBar confidence={confidence} />

      {/* ── Reasoning Steps ─────────────────────────────────────────────── */}
      {reasoning.length > 0 && (
        <ReasoningAccordion steps={reasoning} />
      )}

      {/* ── Supporting Evidence ──────────────────────────────────────────── */}
      {supporting_evidence.length > 0 && (
        <div className="glass-card p-5">
          <div className="flex items-center gap-2 mb-3">
            <FileText size={16} className="text-primary-400" />
            <h4 className="text-sm font-semibold text-white">Supporting Evidence</h4>
            <span className="text-xs text-[var(--text-muted)]">({retrieved_context_count} docs retrieved)</span>
          </div>
          <ul className="space-y-2">
            {supporting_evidence.map((ev, i) => (
              <li key={i} className="flex items-start gap-2 text-sm text-[var(--text-muted)]">
                <span className="text-primary-400 font-mono text-xs mt-0.5">[{i + 1}]</span>
                <span>{ev}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* ── Agent Contributions ──────────────────────────────────────────── */}
      {agent_contributions && (
        <AgentContributions contributions={agent_contributions} />
      )}
    </motion.div>
  )
}
