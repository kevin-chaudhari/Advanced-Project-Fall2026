"""
Diagnostic Expert Agent.

Generates ≥3 failure hypotheses and evaluates each against retrieved evidence.
Returns the most supported hypothesis with detailed reasoning.
"""

from typing import Any, Dict, List

from agents.base_agent import BaseAgent


class DiagnosticExpertAgent(BaseAgent):

    @property
    def role(self) -> str:
        return "Diagnostic Expert"

    @property
    def goal(self) -> str:
        return (
            "Generate at least 3 failure hypotheses for the given industrial "
            "diagnostic question, evaluate evidence for each, and identify the "
            "most probable root cause."
        )

    def build_prompt(self, question: str, context: str, extra: Dict) -> str:
        return f"""
You are a senior industrial equipment diagnostic expert with 20+ years of experience.

QUESTION: {question}

RETRIEVED EVIDENCE:
{context}

INSTRUCTIONS:
1. Generate AT LEAST 3 distinct failure hypotheses relevant to the question.
2. For each hypothesis, evaluate supporting and contradicting evidence from the context.
3. Score each hypothesis (0.0–1.0) based on evidence strength.
4. Select the most supported hypothesis as the primary diagnosis.

Respond ONLY with valid JSON:
{{
  "hypotheses": [
    {{
      "id": 1,
      "hypothesis": "...",
      "supporting_evidence": ["..."],
      "contradicting_evidence": ["..."],
      "score": 0.0
    }}
  ],
  "primary_hypothesis": "...",
  "analysis": "...",
  "confidence": 0.0
}}
"""

    async def run(self, question: str, context: str, extra: Dict = None) -> Dict[str, Any]:
        result = await super().run(question, context, extra)

        # Robust defaults
        result.setdefault("primary_hypothesis", "Unable to determine primary hypothesis.")
        result.setdefault("analysis", "Insufficient data for detailed analysis.")
        result.setdefault("confidence", 0.5)
        result.setdefault("hypotheses", [])

        return result
