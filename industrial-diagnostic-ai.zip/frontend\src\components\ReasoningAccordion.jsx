import { useState } from 'react'
import { ChevronDown, ListOrdered } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'

export default function ReasoningAccordion({ steps }) {
  const [open, setOpen] = useState(false)

  return (
    <div className="glass-card overflow-hidden">
      <button
        id="reasoning-accordion-toggle"
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between p-5 hover:bg-white/5 transition-colors"
        aria-expanded={open}
      >
        <div className="flex items-center gap-2">
          <ListOrdered size={16} className="text-primary-400" />
          <span className="text-sm font-semibold text-white">Step-by-Step Reasoning</span>
          <span className="text-xs text-[var(--text-muted)]">({steps.length} steps)</span>
        </div>
        <motion.div animate={{ rotate: open ? 180 : 0 }} transition={{ duration: 0.2 }}>
          <ChevronDown size={18} className="text-[var(--text-muted)]" />
        </motion.div>
      </button>

      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            key="content"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <div className="px-5 pb-5 space-y-3 border-t border-white/5 pt-4">
              {steps.map((step, i) => (
                <div key={i} className="flex gap-3 items-start">
                  <div className="w-6 h-6 rounded-full bg-primary-500/20 border border-primary-500/40 flex items-center justify-center flex-shrink-0 text-xs font-bold text-primary-400">
                    {i + 1}
                  </div>
                  <p className="text-sm text-[var(--text-muted)] leading-relaxed pt-0.5">{step}</p>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
