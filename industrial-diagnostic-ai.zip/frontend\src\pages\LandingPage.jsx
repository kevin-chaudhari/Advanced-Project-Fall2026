import { useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import {
  Cpu, Database, Zap, Shield, BarChart3, Activity,
  ArrowRight, CheckCircle2, Brain
} from 'lucide-react'
import DatasetCard from '../components/DatasetCard'

const FEATURES = [
  { icon: Brain, label: '6 Specialised Agents', desc: 'Parallel & serial multi-agent pipeline' },
  { icon: Database, label: 'FAISS Vector DB', desc: 'Semantic search across industrial records' },
  { icon: Zap, label: 'RAG Architecture', desc: 'Retrieval-augmented generation' },
  { icon: Shield, label: 'Verification Layer', desc: 'Contradiction removal & ambiguity detection' },
  { icon: BarChart3, label: 'Confidence Scoring', desc: 'Calibrated 0–100% reliability scores' },
  { icon: Activity, label: 'Real-time Reasoning', desc: 'Step-by-step agent breakdowns' },
]

const SAMPLE_QUERIES = [
  'Why is vibration increasing in pump A?',
  'Predict failure cause based on temperature spikes',
  'What anomaly is detected in sensor data?',
  'Is the bearing condition critical?',
  'What maintenance is recommended for the compressor?',
]

export default function LandingPage() {
  const navigate = useNavigate()

  const handleSelect = (datasetId) => navigate(`/chat/${datasetId}`)

  return (
    <div className="min-h-screen grid-bg relative overflow-hidden">
      {/* Background orbs */}
      <div className="absolute top-[-200px] left-[-200px] w-[600px] h-[600px] rounded-full bg-primary-600/10 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-200px] right-[-200px] w-[500px] h-[500px] rounded-full bg-accent-500/10 blur-[120px] pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto px-6 py-16">

        {/* ── Hero ─────────────────────────────────────────────────────── */}
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="text-center mb-20"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-primary-500/30 bg-primary-500/10 text-primary-400 text-sm font-medium mb-6">
            <Cpu size={14} />
            <span>Multi-Agent · RAG · FAISS · Production-Ready</span>
          </div>

          <h1 className="text-5xl md:text-7xl font-extrabold mb-6 leading-tight">
            <span className="gradient-text">Industrial</span>
            <br />
            <span className="text-white">Diagnostic AI</span>
          </h1>

          <p className="text-xl text-[var(--text-muted)] max-w-2xl mx-auto mb-4">
            Ask natural language questions about industrial equipment failures.
            Six specialised AI agents collaborate to deliver precise, evidence-backed diagnoses.
          </p>

          <div className="flex flex-wrap justify-center gap-3 mt-4">
            {SAMPLE_QUERIES.map((q) => (
              <span
                key={q}
                className="text-xs px-3 py-1 rounded-full bg-white/5 border border-white/10 text-[var(--text-muted)]"
              >
                "{q}"
              </span>
            ))}
          </div>
        </motion.div>

        {/* ── Dataset Selection ─────────────────────────────────────────── */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2 }}
        >
          <h2 className="text-2xl font-bold text-center text-white mb-3">
            Select Your Dataset
          </h2>
          <p className="text-center text-[var(--text-muted)] mb-10 text-sm">
            Each dataset has its own dedicated FAISS vector index.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <DatasetCard
              id="failure_iq"
              title="Failure IQ Dataset"
              subtitle="IBM-Style Industrial Sensor Data"
              description="400+ synthetic sensor records covering bearing wear, cavitation, overheating, electrical faults and more. Auto-loaded at startup — no upload needed."
              icon={Activity}
              accentColor="indigo"
              tags={['Auto-loaded', '10 sensor types', '14 failure modes', '400+ records']}
              onSelect={handleSelect}
            />
            <DatasetCard
              id="afrb"
              title="AFRB Dataset"
              subtitle="Asset Failure Root-cause Behaviour"
              description="CSV-based dataset covering asset-level failure root causes, severity ratings, and maintenance recommendations. Upload your own CSV or use the bundled sample."
              icon={Database}
              accentColor="emerald"
              tags={['CSV Upload', 'Root-cause analysis', 'Asset-level', 'Preloaded sample']}
              onSelect={handleSelect}
            />
          </div>
        </motion.div>

        {/* ── Feature Grid ──────────────────────────────────────────────── */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.7 }}
          className="mt-24"
        >
          <h2 className="text-2xl font-bold text-center text-white mb-10">
            System Capabilities
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-5">
            {FEATURES.map(({ icon: Icon, label, desc }, i) => (
              <motion.div
                key={label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 + i * 0.07 }}
                className="glass-card p-5 hover:border-primary-500/60 transition-colors duration-300"
              >
                <div className="w-10 h-10 rounded-lg bg-primary-500/20 flex items-center justify-center mb-3">
                  <Icon size={20} className="text-primary-400" />
                </div>
                <p className="font-semibold text-white text-sm mb-1">{label}</p>
                <p className="text-xs text-[var(--text-muted)]">{desc}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* ── Agent Pipeline Diagram ─────────────────────────────────────── */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="mt-24 glass-card p-8"
        >
          <h2 className="text-xl font-bold text-white mb-6 text-center">
            Multi-Agent Pipeline
          </h2>
          <div className="flex flex-wrap items-center justify-center gap-3 text-sm">
            {[
              { label: 'User Query', color: 'bg-white/10 text-white' },
              { label: '→' },
              { label: 'RAG Retrieval', color: 'bg-indigo-500/20 text-indigo-300' },
              { label: '→' },
              { label: '⚡ Parallel Phase', color: 'bg-amber-500/20 text-amber-300 font-bold' },
              { label: '→' },
              { label: '🔍 Verification', color: 'bg-emerald-500/20 text-emerald-300' },
              { label: '→' },
              { label: '🎯 Ambiguity Check', color: 'bg-purple-500/20 text-purple-300' },
              { label: '→' },
              { label: '✅ Final Output', color: 'bg-green-500/30 text-green-300 font-bold' },
            ].map(({ label, color }, i) => (
              <span
                key={i}
                className={color ? `px-3 py-1.5 rounded-lg ${color}` : 'text-[var(--text-muted)]'}
              >
                {label}
              </span>
            ))}
          </div>
          <div className="mt-4 flex flex-wrap justify-center gap-3 text-xs text-[var(--text-muted)]">
            <span>Parallel: Pattern Recognition Agent</span>
            <span>•</span>
            <span>Aggressive Decision Agent</span>
            <span>•</span>
            <span>Diagnostic Expert Agent</span>
          </div>
        </motion.div>

        {/* ── Footer ───────────────────────────────────────────────────── */}
        <footer className="mt-20 text-center text-xs text-[var(--text-muted)]">
          Industrial Diagnostic AI System — Multi-Agent RAG Architecture v1.0
        </footer>
      </div>
    </div>
  )
}
