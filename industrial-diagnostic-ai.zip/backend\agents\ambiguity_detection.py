"""
Ambiguity Detection Agent.

Detects conflicts, ambiguities, and uncertainties in the verified diagnosis.
Assigns an overall system confidence score and flags for human review if needed.
"""

import json
from typing import Any, Dict

from agents.base_agent import BaseAgent


class AmbiguityDetectionAgent(BaseAgent):

    @property
    def role(self) -> str:
        return "Ambiguity Detection Agent"

    @property
    def goal(self) -> str:
        return (
            "Detect conflicts, ambiguities, and gaps in the verified diagnosis. "
            "Compute a final confidence score and flag whether human review is required."
        )

    def build_prompt(self, question: str, context: str, extra: Dict) -> str:
        verified = extra.get("verification", {})
        ver_text = json.dumps(verified, indent=2) if verified else "Not available"

        return f"""
You are an Ambiguity Detection Specialist in an industrial AI diagnostics system.
Your role is to identify uncertainty, ambiguity, and gaps that may affect decision quality.

ORIGINAL QUESTION: {question}

VERIFIED DIAGNOSIS:
{ver_text}

INSTRUCTIONS:
1. Identify any ambiguous terms or conflicting signals in the verified diagnosis.
2. List specific areas of uncertainty.
3. Compute an overall confidence score (0.0–1.0) for the diagnostic system.
4. Determine if human expert review is required (True if confidence < 0.65 or major conflict).

Respond ONLY with valid JSON:
{{
  "conflicts_detected": ["..."],
  "ambiguous_areas": ["..."],
  "uncertainty_sources": ["..."],
  "overall_confidence": 0.0,
  "human_review_required": false,
  "ambiguity_summary": "..."
}}
"""

    async def run(self, question: str, context: str, extra: Dict = None) -> Dict[str, Any]:
        result = await super().run(question, context, extra)
        result.setdefault("conflicts_detected", [])
        result.setdefault("ambiguous_areas", [])
        result.setdefault("uncertainty_sources", [])
        result.setdefault("overall_confidence", 0.5)
        result.setdefault("human_review_required", False)
        result.setdefault("ambiguity_summary", "No significant ambiguity detected.")
        return result
