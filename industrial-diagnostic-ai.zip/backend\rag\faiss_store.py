"""
FAISS vector store managing TWO separate indexes:
  - failure_iq_index
  - afrb_index
"""

import os
import pickle
from pathlib import Path
from typing import Dict, List, Tuple

import faiss
import numpy as np

from rag.embedder import Embedder
from utils.logger import setup_logger

logger = setup_logger(__name__)


class FAISSStore:
    """Manages multiple named FAISS flat-L2 indexes with document stores."""

    def __init__(self, embedder: Embedder):
        self.embedder = embedder
        self.indexes: Dict[str, faiss.IndexFlatL2] = {}
        self.doc_stores: Dict[str, List[Dict]] = {}  # {index_name: [{content, metadata}]}
        self.persist_path = Path(os.getenv("FAISS_INDEX_PATH", "./faiss_indexes"))
        self.persist_path.mkdir(parents=True, exist_ok=True)

    # ── Build ────────────────────────────────────────────────────────────────

    def build_index(self, name: str, documents: List[Dict]) -> None:
        """
        Build (or rebuild) a FAISS index for the given documents.

        Args:
            name: Index identifier, e.g. 'failure_iq' or 'afrb'
            documents: List of dicts with at least a 'content' key
        """
        logger.info("Building FAISS index '%s' with %d docs …", name, len(documents))
        texts = [doc["content"] for doc in documents]
        embeddings = self.embedder.embed(texts)

        dim = embeddings.shape[1]
        index = faiss.IndexFlatL2(dim)
        index.add(embeddings)

        self.indexes[name] = index
        self.doc_stores[name] = documents

        self._save(name)
        logger.info("Index '%s' built and saved (%d vectors).", name, index.ntotal)

    # ── Search ───────────────────────────────────────────────────────────────

    def search(self, name: str, query: str, top_k: int = 5) -> List[Dict]:
        """
        Semantic similarity search against a named index.

        Returns:
            List of dicts: [{content, metadata, score}] sorted by relevance.
        """
        if name not in self.indexes:
            logger.warning("Index '%s' not found. Returning empty list.", name)
            return []

        query_vec = self.embedder.embed_single(query)
        distances, indices = self.indexes[name].search(query_vec, top_k)

        results = []
        docs = self.doc_stores[name]
        for dist, idx in zip(distances[0], indices[0]):
            if idx == -1:
                continue
            doc = docs[idx].copy()
            # Convert L2 distance to a 0-1 similarity score
            doc["score"] = float(1 / (1 + dist))
            results.append(doc)

        return results

    # ── Persistence ──────────────────────────────────────────────────────────

    def _save(self, name: str) -> None:
        """Persist index and doc store to disk."""
        try:
            faiss.write_index(self.indexes[name], str(self.persist_path / f"{name}.faiss"))
            with open(self.persist_path / f"{name}_docs.pkl", "wb") as f:
                pickle.dump(self.doc_stores[name], f)
        except Exception as exc:
            logger.warning("Could not persist index '%s': %s", name, exc)

    def _load(self, name: str) -> bool:
        """Load a persisted index. Returns True on success."""
        idx_path = self.persist_path / f"{name}.faiss"
        docs_path = self.persist_path / f"{name}_docs.pkl"
        if idx_path.exists() and docs_path.exists():
            try:
                self.indexes[name] = faiss.read_index(str(idx_path))
                with open(docs_path, "rb") as f:
                    self.doc_stores[name] = pickle.load(f)
                logger.info("Loaded persisted index '%s'.", name)
                return True
            except Exception as exc:
                logger.warning("Could not load index '%s': %s", name, exc)
        return False
